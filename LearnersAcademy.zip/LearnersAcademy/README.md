# Learners Academy
An online management system for a school to keep track of its classes, subjects, students, and teachers. It has a single administrator login.