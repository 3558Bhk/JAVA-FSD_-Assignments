package com.FlyAway.services;

import com.FlyAway.models.BookingModel;

public interface BookingServices {
    void createBooking(BookingModel bookingModel);
}
