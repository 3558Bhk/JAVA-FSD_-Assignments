package com.FlyAway.services;

import com.FlyAway.models.PlaceModel;

public interface PlaceServices {
    void createPlace(PlaceModel placeModel);
}
