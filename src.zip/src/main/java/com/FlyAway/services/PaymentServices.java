package com.FlyAway.services;

import com.FlyAway.models.PaymentModel;

public interface PaymentServices {
    void processPayment(PaymentModel paymentModel);
}
